# OpenMDBench 论文源文件与实验数据包

生成时间：2026-10-07 21:15（北京时间）
论文版本：`OpenMDBench_20261007_2112.pdf`（正文 8 页，Fig.1 位于 P2 顶部）+
`OpenMDBench_appendix_20261007_2112.pdf`（附录 9 页）

---

## 包结构

```
OpenMDBench_source_and_data_YYYYMMDD_HHMM/
├── README.md                      # 本说明
├── paper/                         # 最新论文源（可编辑、可编译）
│   ├── main.tex                   #   正文（AAMAS 2027 模板）
│   ├── appendix.tex               #   附录（独立文档，单独编译）
│   ├── refs.bib                   #   参考文献（48 条，均已核验，正式 venue）
│   ├── aamas.cls                  #   模板类文件
│   ├── ACM-Reference-Format.bst   #   参考文献样式
│   ├── by.pdf                     #   CC BY 图标
│   ├── figures/                   #   全部图（PDF；fig_narrative_overview.png 为初稿素材）
│   ├── tables/                    #   全部 LaTeX 表格
│   └── figsrc/                    #   图表生成脚本 + 映射说明（README.md）
├── data/                          # 实验数据（来自 OpenMDBench_release_20261004_0820）
│   ├── paper_data/                #   论文直接引用的权威数据
│   │   ├── grid/                  #     网格实验（dose/六臂/归因/耦合/接口模态）
│   │   ├── hifi_withheld/         #     高保真 14 场景 withheld 集（DATASET_5SEEDS + 场景包）
│   │   └── tournament/            #     循环赛 Elo
│   ├── experiments/               #   实验原始代码+数据（E2/E10/E11/E14 完整版）
│   ├── reports/                   #   实验报告（E1/E5/E6/E7/E10/P0 等）
│   ├── task_lists/                #   实验清单（武昊/肖棹）
│   └── supplement_20261006/       #   10-06 补充数据
│       ├── G1_final_report.md                 #   分级注入-恢复校准最终报告（附录 D 依据；判据 2 终止）
│       ├── P0_GRID_COMPLEX_LAYERED_20261006_p01_complete_v1.zip   #   §6.2 complex 四栈数据（63101-63105）
│       ├── Exp2_blockers.md / Exp2_merged_report.md               #   门禁排除执行说明与合并报告
│       ├── 完整门禁排除名单_28补充场景与14IE场景_20261006.{md,xlsx} #   §6.8 门禁排除名单
│       └── OpenMDBench_P0补实验可行性评估与启动前工作清单_20261006.md
└── docs/                          # 协作记录（合作者对齐纪要）
```

## 论文编译

```bash
cd paper
pdflatex main.tex && bibtex main && pdflatex main.tex && pdflatex main.tex   # 正文
pdflatex appendix.tex && pdflatex appendix.tex                                # 附录（独立文档）
```

编译环境：LaTeX + ACM 模板（aamas.cls 已随包提供）；图片/表格由 figsrc 脚本生成
（系统 python3，无需网络，见 `paper/figsrc/README.md` 的逐项映射）。

## 数据 ↔ 正文对应（关键）

| 正文内容 | 数据 | 脚本 |
|---|---|---|
| Table 3 高保真 14 场景主表 | `data/paper_data/hifi_withheld/DATASET_5SEEDS.json` | `figsrc/build_hifi_tables.py` |
| 附录 G no-intel 消融表 | 同上（no-intelligence 过滤口径） | 同上 |
| 六臂表（tab_p1_seedgrid） | `data/paper_data/grid/` | —（手写表，数据冻结） |
| Fig.3 耦合散点 | `grid/coupling_experiment_medium.json` | `figsrc/draw_coupling_figure.py` |
| Fig.4 端到端差距 | `hifi_withheld/DATASET_5SEEDS.json` | `figsrc/draw_hifi_gap_figure.py` |
| 附录 A Spearman | 同上 | `figsrc/headroom_spearman.py` |
| 附录 A 场景参数表 | `hifi_withheld/scenario_packs/ie_*/`（14 包） | `figsrc/build_scenario_table.py` |

完整映射与手写表的数据背书见 `paper/figsrc/README.md`。

## 版本与注意事项

- **正文当前为 20261007_2112 版**：标题锁定《OpenMDBench: Layering the LLM Only Where It
  Pays》；摘要为缩短版；Fig.1（fig_narrative_overview.pdf）为 2026-10-07 更新版
  （符号已统一为 DF / Bif / IA / headroom，替换了旧版 D1′ 符号）；Fig.1 位于 P2 顶部。
- **符号体系**：DF（decision-form match，门禁）、D2（headroom）、D3（interface budget）、
  IA（信息不对称，诊断非门禁）、Bif（接口信息）、Cinfo（通道信息不对称）。
- **诚实性边界**：E1 判据 2 已终止（分级故障恢复不可达，见
  `data/supplement_20261006/G1_final_report.md`）；Spearman 附录为 −0.68 vs
  原始 CSV −0.67（0.01 舍入差）；旧 grid A10 剂量门勿声称 5/5。
- 实验报告与历史任务清单在 `data/reports/`、`data/task_lists/`；10-06 门禁相关
  （§6.2 complex 数据、§6.8 门禁排除名单、附录 D G1 依据）在 `data/supplement_20261006/`。
